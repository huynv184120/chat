import React, { useState } from 'react'
import Cookies from 'universal-cookie'
import axios from 'axios'
import signinImage from '../assets/signup.jpg'

const cookies = new Cookies()

const initialState = {
    fullname: '',
    username: '',
    password: '',
    confirmPassword: '',
    email: '',
    verifyCode: ''
}



const Auth = () => {
    const [isSignup, setIsSignup] = useState(false)
    const [isVerify, setIsVerify] = useState(false)
    const [form, setForm] = useState(initialState)
    const [failCf, setFailCf] = useState(false)
    const [failVf, setFailVf] = useState(false)
    const [failPw, setFailPw] = useState(false)


    const handleChange = (e) => {
        setForm({ ...form, [e.target.name]: e.target.value })
    }

    const switchMode = () => {
        document.getElementById("form").reset();
        setFailCf(false)
        setFailPw(false)
        setIsSignup((preIsSignup) => !preIsSignup)
    }



    const handleSubmit = async (e) => {
        e.preventDefault()
        const { fullname, username, password, confirmPassword, email, verifyCode } = form
        if (isSignup && (confirmPassword != password)) {
            setFailCf(true)
            return 1
        }
        else {
            // const URL = 'http://localhost:5000/'
            const signup = 'https://chat-web-api.herokuapp.com/v1/auth/register'
            const login = 'https://chat-web-api.herokuapp.com/v1/auth/login'
            const verify = 'https://chat-web-api.herokuapp.com/v1/auth/verify'
            if (isVerify) {

                const data = await axios.post(verify, { email, verifyCode })
                // console.log(data)

                if (data.status == 200) {

                    setIsVerify(false)
                    setIsSignup(false)
                }
                else {
                    setFailVf(true)
                    return
                }
            } else
                if (isSignup) {


                    const data = await axios.post(signup, { fullname, username, password, email })
                    if (data.status == 200) {
                        setIsVerify(true)
                    }
                }
                else {

                    try {
                        const data = await axios.post(login, { password, email })

                        const { token, userId } = data.data.data
                        cookies.set('token', token)
                        cookies.set('userId', userId)
                        window.location.reload()
                    } catch (error) {
                        setFailPw(true)
                    }




                }
        }




        // if(isSignup){
        // cookies.set('phoneNumber', phoneNumber)
        // cookies.set('avatarURL', avatarURL)
        // cookies.set('hashedPassword', hashedPassword)
        // }
        // window.location.reload()
    }



    return (
        <div className="auth__form-container">
            <div className="auth__form-container_fields">
                <div className="auth__form-container_fields-content">
                    <p>{isVerify && 'Enter Verify Code'}</p>
                    <p>{(!isVerify) && (isSignup ? 'sign up' : 'sign in')}</p>
                    <form id='form' onSubmit={handleSubmit}>
                        {(!isVerify) && isSignup &&
                            (<div className="auth__form-container_fields-content_input">
                                <label htmlFor='fullname'>Full name</label>
                                <input
                                    name="fullname"
                                    type="text"
                                    placeholder="full name"
                                    onChange={handleChange}
                                    required
                                />
                            </div>)}

                        {(!isVerify) && <div className="auth__form-container_fields-content_input">
                            <label htmlFor='email'>Email</label>
                            <input
                                name="email"
                                type="email"
                                placeholder="email"
                                onChange={handleChange}
                                required
                            />
                        </div>}

                        {(!isVerify) && isSignup && <div className="auth__form-container_fields-content_input">
                            <label htmlFor='userName'>User name</label>
                            <input
                                name="username"
                                type="text"
                                placeholder="Username"
                                onChange={handleChange}
                                required
                            />
                        </div>}

                        {(!isVerify) && <div className="auth__form-container_fields-content_input">
                            <label htmlFor='password'>Password</label>
                            <input
                                name="password"
                                type="password"
                                placeholder="Password"
                                onChange={handleChange}
                                required
                            />
                            {failPw && (<label htmlFor='verifyCode'><p style={{ color: 'red', fontSize: 10 }}>Password or Acount is failed</p></label>)}

                        </div>}
                        {(!isVerify) && isSignup &&
                            (<div className="auth__form-container_fields-content_input">
                                <label htmlFor='confirmPassword'>Confirm password</label>
                                <input
                                    name="confirmPassword"
                                    type="password"
                                    placeholder="Confirm password"
                                    onChange={handleChange}
                                    required
                                />
                                {failCf && (<label htmlFor='confirmPassword'><p style={{ color: 'red', fontSize: 10 }}>Confirm password is not match</p></label>)}
                            </div>)}


                        {isVerify &&
                            (<div className="auth__form-container_fields-content_input">
                                <label htmlFor='verifyCode'>Verify Code</label>
                                <input
                                    name="verifyCode"
                                    type="text"
                                    maxLength={6}
                                    placeholder="verifyCode"
                                    onChange={handleChange}
                                    required
                                />
                                {failCf && (<label htmlFor='verifyCode'><p style={{ color: 'red', fontSize: 10 }}>verify code is failed</p></label>)}

                            </div>)}


                        <div className='auth__form-container_fields-content_button'>
                            <button >
                                {(isVerify) && "Submit"}
                                {(!isVerify) && (isSignup ? "Sign up" : "Sign in")}
                            </button>
                        </div>

                    </form>
                    {(!isVerify) && <div className="auth__form-container_fields-account">
                        <p>
                            {isSignup
                                ? "Already have an account ?"
                                : "Don't have an account ?"
                            }
                            <span onClick={switchMode}>
                                {isSignup ? "Sign in" : "Sign up"}
                            </span>
                        </p>
                    </div>}
                </div>
            </div>

            <div className="auth__form-container_image">
                <img src={signinImage} alt="signin" />
            </div>

        </div>
    )
}

export default Auth
