import React from 'react'

function TeamMessage() {
    return (
        <div>
            this is team message
        </div>
    )
}

export default TeamMessage
