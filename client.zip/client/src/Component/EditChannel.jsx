import React from 'react'

function EditChannel() {
    return (
        <div>
            this edit channel
        </div>
    )
}

export default EditChannel
