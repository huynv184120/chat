import React, { useState } from 'react'
import Cookies from 'universal-cookie'
import axios from 'axios'
import signinImage from '../assets/signup.jpg'

const cookies = new Cookies()

const initialState = {
    fullname:'',
    username:'',
    password:'',
    confirmPassword:'',
    email:''
}



const Auth = () => {
    const [isSignup, setIsSignup] = useState(false)
    const [form, setForm] = useState(initialState)

    const handleChange = (e) => {
        setForm({...form, [e.target.name]:e.target.value })
    }

    const switchMode = () => {
        setIsSignup((preIsSignup) => !preIsSignup)
    }

    const handleSubmit = async(e) => {
        e.preventDefault()
        console.log(form)
        const {fullname, username, password, email} = form
        const URL = 'http://localhost:5000/'
        // const signup = 'https://chat-web-api.herokuapp.com/v1/auth/register'
        const  {data:{token, userId}} = await axios.post(`${URL}${isSignup ? 'signup' : 'login'}`, {fullname, username, password, email})
        // console.log(`${token}aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa`)
        cookies.set('token',token)
        cookies.set('userId', userId)
        

        // if(isSignup){
            // cookies.set('phoneNumber', phoneNumber)
            // cookies.set('avatarURL', avatarURL)
            // cookies.set('hashedPassword', hashedPassword)
        // }
        window.location.reload()
    }
    


    return (
        <div className="auth__form-container">
            <div className="auth__form-container_fields">
                <div className="auth__form-container_fields-content">
                    <p>{isSignup ? 'sign up' : 'sign in'}</p>
                    <form onSubmit={handleSubmit}>
                        {isSignup &&
                            (<div className="auth__form-container_fields-content_input">
                                <label htmlFor='fullname'>Full name</label>
                                <input
                                    name="fullname"
                                    type="text"
                                    placeholder="full name"
                                    onChange={handleChange}
                                    required
                                />
                            </div>)}

                        <div className="auth__form-container_fields-content_input">
                                <label htmlFor='email'>Email</label>
                                <input
                                    name="email"
                                    type="email"
                                    placeholder="email"
                                    onChange={handleChange}
                                    required
                                />
                        </div>

                        {isSignup&&<div className="auth__form-container_fields-content_input">
                            <label htmlFor='userName'>User name</label>
                            <input
                                name="username"
                                type="text"
                                placeholder="Username"
                                onChange={handleChange}
                                required
                            />
                        </div>}
                        
                        <div className="auth__form-container_fields-content_input">
                            <label htmlFor='password'>Password</label>
                            <input
                                name="password"
                                type="password"
                                placeholder="Password"
                                onChange={handleChange}
                                required
                            />
                        </div>
                        {isSignup&&
                        ( <div className="auth__form-container_fields-content_input">
                            <label htmlFor='confirmPassword'>Confirm password</label>
                            <input
                                name="confirmPassword"
                                type="password"
                                placeholder="Confirm password"
                                onChange={handleChange}
                                required
                            /></div>)}
                    <div className='auth__form-container_fields-content_button'>
                            <button >
                                {isSignup?"Sign up":"Sign in"}
                            </button>
                    </div>
                            
                    </form>
                    <div className="auth__form-container_fields-account">
                        <p>
                            {isSignup
                            ? "Already have an account ?"
                            : "Don't have an account ?"
                            }
                            <span onClick={switchMode}>
                                {isSignup ? "Sign in" : "Sign up" }
                            </span>
                        </p>
                    </div>
                </div>
            </div>

            <div className="auth__form-container_image">
                <img src={signinImage} alt="signin"/>
            </div>

        </div>
    )
}

export default Auth
